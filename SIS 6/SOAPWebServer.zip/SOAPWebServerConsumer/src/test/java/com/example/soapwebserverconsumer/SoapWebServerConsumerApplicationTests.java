package com.example.soapwebserverconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapWebServerConsumerApplicationTests {

    @Test
    void contextLoads() {
    }

}
